/*
 * Filename: array.c
 */

#include<stdio.h>

void main()
{
    int array[10] = {11,8,3,22,59,6,16,0,3,2};
    int i = 0;

    for(i=0; i<10; i++)
    {
        printf("%d ", array[i]);
    }
}

