/*
 * Filename: if.c
 *
 */
#include<stdio.h>

void main()
{
    int a = 1;
    int b = 9;
    
    if(a < b)
    {
        printf("a < b\n");
    }
    else
    {
        printf("a >= b\n");
    }
}

