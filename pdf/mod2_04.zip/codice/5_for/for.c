/*
 * Filename: for.c
 *
 */

#include<stdio.h>

void main()
{

    int i=0;
    int k=10;

    for(i=0; i<k; i++)
    {
        printf("%d\n", i);
    }


}
